import fatec.poo.model.Aluno;
import java.util.Scanner;

public class Aplic {
    public static void main(String[] args) {
        int raAluno, opcao;
        double notaProva1, notaProva2, notaTrab1, notaTrab2;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Digite o RA: ");
        raAluno = entrada.nextInt();
        
        Aluno objAluno = new Aluno(raAluno);
        
        System.out.print("Digite a nota da Prova 1: ");
        notaProva1 = entrada.nextDouble();
        System.out.print("Digite a nota da Prova 2: ");
        notaProva2 = entrada.nextDouble();
        System.out.print("Digite a nota do Trabalho 1: ");
        notaTrab1 = entrada.nextDouble();
        System.out.print("Digite a nota do Trabalho 2: ");
        notaTrab2 = entrada.nextDouble();
        
        objAluno.setNotaPrUm(notaProva1);
        objAluno.setNotaPrDois(notaProva2);
        objAluno.setNotaTrUm(notaTrab1);
        objAluno.setNotaTrDois(notaTrab2);

        do{
            System.out.println("\n1 - Exibir Nota das Provas/Trabalhos");
            System.out.println("2 - Exibir Média das Provas/Trabalhos");
            System.out.println("3 - Exibir Média Final");
            System.out.println("4 - Sair");
            System.out.print("\nDigite a opção: ");
            opcao = entrada.nextInt();
            
            switch(opcao){
                case 1:
                    System.out.println("A nota das provas do aluno " + objAluno.getRa() + " são: Prova 1: " 
                    + objAluno.getNotaPrUm() + " , Prova 2: " + objAluno.getNotaPrDois() + " , Trabalho 1: " 
                    + objAluno.getNotaTrUm() + " e Trabalho 2: " + objAluno.getNotaTrDois() + ".");
                break;
                case 2:
                   System.out.println("A média dos trabalhos do aluno " + objAluno.getRa() + " é de " 
                   + objAluno.calcMediaTrab() + " e a média de provas é de " + objAluno.calcMediaProva() + ".");
                break;
                case 3:
                   System.out.println("A média final do aluno " + objAluno.getRa() + " é igual a "
                   + objAluno.calcMediaFinal() + ".");
            }
        } while (opcao < 4);
    }
    
}
