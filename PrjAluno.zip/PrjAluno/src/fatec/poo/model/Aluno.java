package fatec.poo.model;

public class Aluno {
    //atributos
    int ra;
    double notaPrUm, notaPrDois, notaTrUm, notaTrDois;

    public Aluno(int ra) {
        this.ra = ra;
    }

    
    public void setRa(int ra) {
        this.ra = ra;
    }

    public void setNotaPrUm(double notaPrUm) {
        this.notaPrUm = notaPrUm;
    }

    public void setNotaPrDois(double notaPrDois) {
        this.notaPrDois = notaPrDois;
    }

    public void setNotaTrUm(double notaTrUm) {
        this.notaTrUm = notaTrUm;
    }

    public void setNotaTrDois(double notaTrDois) {
        this.notaTrDois = notaTrDois;
    }

    public int getRa() {
        return ra;
    }

    public double getNotaPrUm() {
        return notaPrUm;
    }

    public double getNotaPrDois() {
        return notaPrDois;
    }

    public double getNotaTrUm() {
        return notaTrUm;
    }

    public double getNotaTrDois() {
        return notaTrDois;
    }

    public double calcMediaProva(){
        return(0.75 * ((notaPrUm + (2 * notaPrDois)) / 3));
    }
    
    public double calcMediaTrab(){
        return(.25 * ((notaTrUm + notaTrDois) / 2));
    }
    
    public double calcMediaFinal(){
        return(calcMediaProva() + calcMediaTrab());
    }
}
