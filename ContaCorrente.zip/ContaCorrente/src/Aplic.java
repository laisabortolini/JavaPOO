import fatec.poo.model.ContaCorrente;
import java.util.Scanner;

public class Aplic {
    public static void main(String[] args) {
    Scanner entrada = new Scanner (System.in);
    int numConta, opcao;
    double saldoConta, valDep, valSaque;
    
    System.out.println("Insira o número da conta: ");
    numConta = entrada.nextInt();
    System.out.println("Insira o saldo disponível em sua conta.");
    saldoConta = entrada.nextDouble();
    
   ContaCorrente objConta = new ContaCorrente(numConta, saldoConta);
    
    do{
        
        System.out.println("\n1 - Depositar");
            System.out.println("2 - Sacar");
            System.out.println("3 - Consultar Saldo");
            System.out.println("4 - Sair");
            System.out.print("\n\tDigite a opção: ");
            opcao = entrada.nextInt();
        
            System.out.println("\nNúmero da conta: " + objConta.getNumero());

        switch(opcao){ 
                case 1: System.out.println("Deposito de valor ");
                        valDep = entrada.nextDouble();
                        objConta.depositar(valDep);
                        break;
                case 2: System.out.print("\nDigite o valor do saque: ");
                         valSaque = entrada.nextDouble();
                         if (valSaque <= objConta.getSaldo()){
                             objConta.sacar(valSaque); //passagem de mensagem
                         }else{
                             System.out.println("Saldo Insuficiente");
                         }    
                         break;                    
                case 3: System.out.println("O atual saldo da conta é R$" + objConta.getSaldo() + ".");
        }
    } while(opcao < 4);  
}
}