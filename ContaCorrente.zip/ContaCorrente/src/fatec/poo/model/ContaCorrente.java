package fatec.poo.model;

public class ContaCorrente {
    //atributos
    int numero;
    double saldo;
    
    // metodo construtor
        public ContaCorrente(int numero, double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }
    //metodos especiais
    public int getNumero() {
        return numero;
    }
    public double getSaldo() {
        return saldo;
    }
    
    public void sacar(double s){
        saldo -= s;
    }
    public void depositar(double d){
        saldo += d;
    }
}
