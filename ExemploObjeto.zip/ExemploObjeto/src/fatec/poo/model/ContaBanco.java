package fatec.poo.model;

public class ContaBanco {
    //atributos
    public int numConta;
    protected String tipo;
    private String dono;
    private float saldo;
    private boolean status;

    //métodos personalizados
    public void estadoAtual(){
        System.out.println("Conta: " + this.getNumConta());
        System.out.println("Tipo de conta: " + this.getTipo());
        System.out.println("Pertencente a: " + this.getDono());
        System.out.println("Com o saldo atual de: " + this.getSaldo());
        System.out.println("Status atual: " + this.getStatus());
    }
    public ContaBanco() {
        //this.saldo = 0;
        //this.status = false;
    }
     public void abrirConta(String tipo){
        this.setTipo(tipo);
        this.setStatus(true);
        
        if ("CC".equals(tipo)){
            this.setSaldo(50);
        } else if ("CP".equals(tipo)){
            this.setSaldo(150);
        }
    }
    public void fecharConta(){
        if (this.getSaldo() > 0){
            System.out.println("Conta com dinheiro");
        } else if (this.getSaldo() < 0){
            System.out.println("Conta em dívida");
        } else {
            this.setStatus(false);
            System.out.println("Conta fechada com sucesso!");
        }
    }
    
    public void depositar(float v){
        if (this.getStatus()){
            this.setSaldo(this.getSaldo() + v);
            System.out.println("Depósito realizado com sucesso na conta de " + this.getDono());
        } else {
             System.out.println("Impossível depositar em uma conta fechada!");
        }
    }
    
    public void sacar(float v){
         if (this.getStatus()){
             if (this.getSaldo() >= v){
                this.setSaldo(this.getSaldo() - v);
                System.out.println("Saque realizado com sucesso na conta de " + this.getDono());
            } else {
                System.out.println("Saldo insuficiente para saque"); 
            } 
         } else {
            System.out.println("Impossível sacar de uma conta fechada!");
         }
    }
    
    public void pagarMensal(){
        int v = 0;
        if ("CC".equals(tipo)){
            v = 12;
        } else if ("CP".equals(tipo)) {
            v = 20;
        }
        if (this.getStatus()){
        this.setSaldo(getSaldo() - v);
        System.out.println("Mensalidade paga com sucesso por " + this.getDono());
        } else {
            System.out.println("Impossivel pagar mensalidade");
        }
    }
    //métodos especiais - acesso e modificador
    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }
    public int getNumConta() {
        return numConta;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public String getTipo() {
        return tipo;
    }
    public void setDono(String dono) {
        this.dono = dono;
    }
    public String getDono() {
        return dono;
    }    
    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    public float getSaldo() {
        return saldo;
    }    
    public void setStatus(boolean status) {
        this.status = status;
    }
    public boolean getStatus() {
        return status;
    }    
  
}
