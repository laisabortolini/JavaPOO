import fatec.poo.model.ContaBanco;

public class Aplic {
    public static void main(String[] args) {
    ContaBanco p1 = new ContaBanco();
    p1.setNumConta(111);
    p1.setDono("Daniel");
    p1.abrirConta("CC");
    p1.getSaldo();
   
        
    ContaBanco p2 = new ContaBanco();
    p2.setNumConta(121);
    p2.setDono("Daniele");
    p2.abrirConta("CP");
    p2.getSaldo();
   

    p1.depositar(300);
    p2.depositar(500);
    p1.sacar(350);
    p1.fecharConta();
    p1.estadoAtual();
    p2.estadoAtual();
    }
}
