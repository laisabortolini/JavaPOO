import fatec.poo.model.Circulo;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Aplic {
    public static void main(String[] args) {
        double medRaio;
        int opcao;
        String unidade;
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");
   
        System.out.println("Insira unidade de medida: ");
        unidade = entrada.next();
        
        Circulo c1 = new Circulo(unidade);
        
        System.out.print("Digite a medida do raio: ");
        medRaio = entrada.nextDouble();
    
        c1.setRaio(medRaio);

    do{
        System.out.println("\n1 - Consultar Área");
        System.out.println("\n2 - Consultar Perimetro");
        System.out.println("\n3 - Consultar Diâmetro");
        System.out.println("\n4 - Sair");
        System.out.println("\nDigite a opção: ");
        opcao = entrada.nextInt();

        switch (opcao){
            case 1:
                System.out.println("\nMedida da área: " + df.format(c1.calcArea()) + " " + c1.getUnidadeMedida());
                break;
            case 2:
                System.out.println("\nMedida do perímetro: " + df.format(c1.calcPerimetro()) + " " + c1.getUnidadeMedida());
                break;
            case 3:
                System.out.println("\nMedida do diâmetro: " + df.format(c1.calcDiametro()) + " " + c1.getUnidadeMedida());
                break;
        }
        } while ( opcao < 4);
    }
}

