package fatec.poo.model;

public class Circulo {
    //atributo
    private double raio;
    private String unidadeMedida;
    //metodos

    public Circulo(String uniMed) {
        this.unidadeMedida = uniMed;
    }

    public Circulo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    public double getRaio() {
        return raio;
    }

    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }

    public String getUnidadeMedida() {
        return unidadeMedida;
    }
    
    public double calcArea(){
        return(Math.PI * Math.pow(raio,2));
    }
    public double calcPerimetro(){
        return((2 * Math.PI) * this.raio);
    }
    public double calcDiametro(){
        return(2 * this.raio);                
    }
}
