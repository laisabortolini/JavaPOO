package fatec.poo.model;

/**
 * @author borto
 */
public class objinstc {
    public static void main(String[] args) {
        Caneta c1 = new Caneta();
        c1.modelo = "Bic Cristal";
        c1.cor = "Azul";
       // c1.ponta = 0.5;
        c1.carga = 80;
        //c1.tampada = false;
       //c1.destampar();
       c1.tampar();
        c1.rabiscar();
        c1.status();
    }
    
}
